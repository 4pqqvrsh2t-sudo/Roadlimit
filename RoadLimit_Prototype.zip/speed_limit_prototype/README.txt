ROADLIMIT PROTOTYPE — PHONE TEST

What it does
- Uses the phone's high-accuracy GPS continuously.
- Queries OpenStreetMap road geometry within ~90 m of the phone.
- Matches the GPS point to the most plausible road using distance and driving heading.
- Reads the OSM `maxspeed` tag and converts km/h to mph.
- Updates automatically as you move.

Important limitation
This is a prototype. OSM coverage and maxspeed tagging varies by road and jurisdiction, and a missing OSM speed-limit tag is shown as “—” rather than guessed. Do not use this as a substitute for posted signs or official navigation data.

EASIEST TEST TOMORROW
1. Put index.html on a HTTPS web host (GitHub Pages, Netlify, etc.).
2. Open the HTTPS address in Safari on your iPhone.
3. Allow Location access.
4. Tap START GPS.
5. Drive only where it is safe/legal to test and compare the displayed limit with the actual posted sign.

LOCAL TEST OPTION
If you have a computer on the same Wi‑Fi:
  python3 -m http.server 8000 --bind 0.0.0.0
Then browse to http://COMPUTER-IP:8000 from another device. iOS Safari normally requires a secure context (HTTPS) for geolocation, so a simple LAN HTTP page may not be allowed to use GPS. Use HTTPS hosting for the actual phone test.

Next upgrade
For production-grade accuracy, replace OSM/Overpass with an authoritative speed-limit dataset or commercial road-speed service, plus a downloaded vector-tile/road graph and a proper map-matching engine.
